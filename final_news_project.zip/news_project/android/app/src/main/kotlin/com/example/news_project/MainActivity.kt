package com.example.news_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
